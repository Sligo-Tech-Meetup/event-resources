# Sligo Tech Meetups
Community-driven monthly tech meetups in Sligo.